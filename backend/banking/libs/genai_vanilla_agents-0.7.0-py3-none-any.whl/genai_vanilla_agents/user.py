class User:
    def __init__(self, id = "user", mode = "interactive", description = "A human user that interacts with the system. Can provide input to the chat"):
        self.id = id
        self.mode = mode
        self.description = description
        
    def ask(self, messages: list):
        if (self.mode == "interactive"):        
            # Get user input from command line prompt
            user_input = input(f"{self.id}: ")
            messages.append({"role": "user", "content": user_input, "name": self.id})
            return None
        elif (self.mode == "unattended"):
            return "stop"