from .askable import Askable
from .llm import LLM

import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

class Workflow():
    def __init__(self, askable: Askable, messages: list = [], system_prompt: str = ""):
        self.askable = askable
        self.messages = messages
        self.system_prompt = system_prompt
        
        logger.debug("Workflow initialized")

    def run(self, input: str):
        logger.debug("Running workflow with input: %s", input)
        
        if len(self.messages) == 0:
            self.messages.append({"role": "system", "content": self.system_prompt})
            logger.debug("Added system prompt to messages: %s", self.system_prompt)
            
        self.messages.append({"role": "user", "content": input})
        logger.debug("Added user input to messages: %s", input)
        
        execution_result = self.askable.ask(self.messages)
            
        return execution_result
    
    def restart(self):        
        self.messages = []
        logger.debug("Restarted workflow, cleared messages.")
        